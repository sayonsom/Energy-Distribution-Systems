# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 21:17:43 2016

@author: user
"""

import numpy as np

cust1kVA = [25,80.0,90,10] #all these values are div demands sorts
cust2kVA = [25,80,30.0,10]
time = range(1,5) #for 1 to 4 pm
transformerrating = 100.0
#np.max(cust1kVA)

#Non coincident maximum demand = sum of individual customer demand

Noncoinmax = np.max(cust1kVA) + np.max(cust2kVA) #+ so on for all customers
print('Non-coincident Max Demand = %f' %Noncoinmax)

#load factor = Avg time duration kVA demand/Max kVA demand in that time duration

LF = np.average(cust1kVA)/np.max(cust1kVA)
print('Load Factor = %f' %LF)

#Diversity Factor = Non coincident maximum demand/ Max Diversified Demand
DF = Noncoinmax/np.max(cust1kVA)
print('Diversity Factor = %f' %DF)

#Coincidence Factor
CF = 1/DF
print('Coincidence Factor = %f' %CF)

#Utilization Factor is the ratio of max KVA Demand by Transformer Rating
UF = np.max(cust1kVA)/transformerrating
print('Utilization Factor = %f' %UF)

