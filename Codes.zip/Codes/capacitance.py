## Assume the strands of the conductor 19 Strands

dc = #inches, diameter of phase conductor
ds = #inches, outside diameter of the tape shield
rho = #Assume temperature to be 20 deg Celcius
r_shield = 7.9835e8*(rho/ds*T) #ohms per mile, no conversion of unit is required
GMRTape_Shield = (ds/2) - (T/2000))/12 #feet
