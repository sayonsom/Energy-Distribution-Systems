# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 17:00:56 2016

@author: user
"""
import numpy as np
import cmath

def problemone():
    #from, to, distance, distributed load, conc load at the end
    network = np.array([[1,2,0.50,0,500],
                        [2,3,0.65,0,1200],
                        [3,4,0.90,0,750]])
    kdrop = 0.00298639 #drop/kva/mile
    krise = 0.00334353 #rise/kva/mile
    cols = len(network)/network.size
    totalload = 0
    vdroptotal = 0
    for i in range(len(network)):
        totalload += network[i,4]
    
    print('\n \nTotal Load in the network = %f kVA\n' %totalload)
        
    for i in range(len(network)):
        vdrop = totalload*kdrop*network[i,2]
        print('\nVoltage drop between %d and %d is %f percent' %(network[i,0], network[i,1], vdrop))
        totalload = totalload - network[i,3]-network[i,4]
        vdroptotal += vdrop
        
    print('\n------------------------------------\nTotal V-drop is: %f percent\n---------------------------------------' %vdroptotal)
    
    droplimit = 5
    locationofcap = 3
    distanceuntilcap = 1.15
    
    requiredcaprating = (vdroptotal-droplimit)/(krise*distanceuntilcap)
    requiredcapratingrounded = (np.ceil(requiredcaprating/300)+1)*300
    
    print ('\n Required Capacitor for Vrise within limit =  %f KVAR (Rounded: %d KVAR)' %(requiredcaprating,requiredcapratingrounded))
    print ('\n ----------------------\nPROBLEM 1 FINISHED \n ----------------------')
    return("")


def problemtwo():
    '''
    Rectangular Area
    '''
    vll = 4.16 #kV
    length = 12000/5280.0 #ft to miles
    width = 2500*2/5280.0 #ft to miles
    area = length*width
    loaddensity = 2000 #kVA per square mile
    pf = 0.9
    totalload = area*loaddensity
    r_fd = 0.1859 #556500 ACSR
    GMR_fd = 0.0313 #ft 556500 ACSR
    Deq_fd = 3.5 #ft given in problem
    Z_fd = r_fd + 1j*0.12134* np.log(Deq_fd/GMR_fd)
    print ("\nImpedance of Feeder %s = " %Z_fd)
    
    r_lat = 0.385 #226800 ACSR
    GMR_lat = 0.0217 #ft 226800 ACSR
    Deq_lat = 3.5 #ft given in problem
    Z_lat = r_lat + 1j*0.12134* np.log(Deq_lat/GMR_lat)
    print ("\nImpedance of Lateral %s = " %Z_lat)
    #at point A
    parts = 10
    areaA = (length/parts)*(width/2)
    IA = (loaddensity*areaA)/(1.732*vll)
    IAang = 0 - np.rad2deg(np.arccos(pf))
    print('\nCurrent in the lateral at Pt. A = %f /__ %f' %(IA, IAang))
    IA = cmath.rect(IA,np.deg2rad(IAang))
    ZlatA = Z_lat*(width/2)
    VdropA = np.real(0.5*ZlatA*IA)
    print('V Drop of the lateral = %f' %VdropA)
    VdropPC = (VdropA/(1000*(vll/np.sqrt(3))))*100
    print('V Drop Percentage = %f' %VdropPC)
    #at point B
    ZptB = (Z_fd*length)+(Z_lat*width/2)
    print(ZptB)
    #Power Loss of a feeder or lateral, find once for each case of lateral
    #or feeder
    Ploss = 3*((1/3)*np.real(Z*I**2))/(1000)


def problemthree():
    density = 6000
    area_rect = 1
    load_rect = area_rect*density
    area_tri = 1
    load_tri = area_tri*density     
    kdrop = 1
    krise = 1
    length = 1
    vdrop_rect = kdrop*(length/2)*(load_rect)
    vdrop_tri = kdrop*(length/2)*(load_rect)
    

    