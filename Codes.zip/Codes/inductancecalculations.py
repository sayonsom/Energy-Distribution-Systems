# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 20:50:46 2016

@author: user
"""
import numpy as np

d=[5,5,8]
rprime = 0.7788
dia = 5 #cm

def gmr(dia):
    r = (dia/200.0)
    return rprime*r

def gmd(d):
    
    x=1
    for i in range(len(d)):
        x *= d[i]
        
    gmd = x**(1.0/len(d))
    return gmd
    
GMD=gmd(d)
GMR=gmr(dia)

l = 2*(10**(-1))*np.log((GMD)/(GMR))
Xl = 2*3.142*60*l

print('Inductance of the system is: %f microHenry per meter' %l)  
print('Inductive Reactance of the system is: %f ohms per meter' %Xl) 

