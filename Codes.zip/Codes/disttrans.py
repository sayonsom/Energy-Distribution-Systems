# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 10:22:55 2016

@author: user
"""
import numpy as np

#This is about distribution transformers

#voltage conversion


systems ={
    'phases' : 3,
    'xfrmr_kva_rating' :  50.0,
    'xfrmr_rated_primary' : 12.47,
    'xfrmr_rated_secondary' : 0.240,
    'xfrmr_primary_connection' : 'star',
    'xfrmr_secondary_connection' : 'delta',
    'xfrmr_imp' :  '1.1 + 1j*3.0', #[units in percentage, needs to be divided by 100 for P.U]
    'secondary_kWload' : 480.0,
    'secondary_kWload_known' : True,
    'secondary_kVAload_known' : True,
    'secondary_kVAload' : 80.0,    
    'loadbalance' : 'Balanced',
    'loadvoltage_known': False,
    'loadvoltagell' : 0.235,
    'pf' : 0.91,
    'lag' : 'lag',
    'single_phase_load_attached': True,
    'single_phase_load_phase_from' : 'a',
    'single_phase_load_phase_to' : 'n',
    'single_phase_load_vll': 120.0,
    'single_phase_load_kva': 9.0,
    'single_phase_load_pf': 1.0,
    
    }

def turnsratio():
    if systems['xfrmr_primary_connection'] == 'star':  
        primaryvoltage = (systems['xfrmr_rated_primary'])/1.732
    else:
        primaryvoltage = (systems['xfrmr_rated_primary'])
        
    if systems['xfrmr_secondary_connection'] == 'star':  
        secondaryvoltage = (systems['xfrmr_rated_secondary'])/1.732
    else:
        secondaryvoltage = (systems['xfrmr_rated_secondary'])
    return primaryvoltage/secondaryvoltage
    
def secondarylinecurrents():
    kVAload = systems['secondary_kVAload']
    #systems['secondary_kWload']
    #lvll = systems['loadvoltagell']
    pf = systems['pf']
    if systems['secondary_kVAload_known'] == False or kVAload == 0.0:     
        if systems['secondary_kWload_known'] == False:
            print('\n -------- \n Incomplete Data, Cannot Compute \n -------')
            return "Try Again"
        else:
            kWload = systems['secondary_kWload']
            kVAload = kWload/pf
    theta = np.arccos(pf)
    if systems['loadvoltage_known'] == True:
        lvll = systems['loadvoltagell']
    else:
        lvll = systems['xfrmr_rated_secondary']
    if systems['lag'] == 'lag':
         theta = -theta
    else:
        theta = theta
    theta = np.rad2deg(theta)
    IloadMag = (kVAload)/(1.732*lvll)
    IloadAng = theta
    kWload = pf*kVAload
    print('\n>>> Secondary kVA Load: %f | kW Load: %f | type: %s | pf: %f (%s)' %(kVAload,kWload,systems['loadbalance'], pf, systems['lag']))    
    print('\nUsing A phase current as the reference:\n') 
    print('>>> Ia = %f /__ %f' %(IloadMag,IloadAng))
    print('>>> Ib = %f /__ %f' %(IloadMag,IloadAng-120))
    print('>>> Ic = %f /__ %f' %(IloadMag,IloadAng+120))
    
        
    if  systems['single_phase_load_attached'] == True:
        angulardisplacement = 30 #degrees, need to automate this further
        single_phase_current_mag =  (systems['single_phase_load_kva']*1000)/(systems['single_phase_load_vll'])
        single_phase_current_ang =  angulardisplacement - np.rad2deg(np.arccos(systems['single_phase_load_pf']))
        print('>>> Single Phase Current = %f /__ %f' %(single_phase_current_mag,single_phase_current_ang))
        
    
    return IloadMag,IloadAng, IloadMag, IloadAng-120, IloadMag,IloadAng+120
    
def primarylinecurrents():
    print('Step 1: Turns Ratio\n-------------------- ')
    n = turnsratio()
    print('\n n = %d' %n)
    print('Step 2: Calculate the Primary Currents\n-------------------- ')
    Ia,IaAng,Ib,IbAng,Ic,IcAng = secondarylinecurrents()
    IA = Ia/(n*1.732)
    IAAng = IaAng - 30
    IB = IA
    IBAng = IbAng - 30
    IC = IA
    ICAng = IcAng - 30
    print('>>> IA = %f /__ %f' %(IA,IAAng))
    print('>>> IB = %f /__ %f' %(IB,IBAng))
    print('>>> IC = %f /__ %f' %(IC,ICAng))
    return IA,IAAng, IB,IBAng, IC,ICAng   
    
def currentinsecondarydelta():
    Ia,IaAng,Ib,IbAng,Ic,IcAng = secondarylinecurrents()
    Ica = Ia/(1.732)
    IcaAng = IaAng - 30
    Iab = Ib/(1.732)
    IabAng = IbAng - 30
    Ibc = Ic/(1.732)
    IbcAng = IcAng - 30
    print('>>> Ica = %f /__ %f' %(Ica,IcaAng))
    print('>>> Iab = %f /__ %f' %(Iab,IabAng))
    print('>>> Ibc = %f /__ %f' %(Ibc,IbcAng))
    return Ica,IcaAng, Iab,IabAng, Ibc,IbcAng
    
def realpowerloss():
    '''
    Impedance is to be computed after transfering the impedance to low
    side of the transformer
    '''
    phases = systems['phases']
    imped = systems['xfrmr_imp']/100
    kVAload = systems['secondary_kVAload']
    lvll = systems['loadvoltagell']
    pf = systems['pf']
    if systems['secondary_kVAload_known'] == False or kVAload == 0.0:     
        if systems['secondary_kWload_known'] == False:
            print('\n -------- \n Incomplete Data, Cannot Compute \n -------')
            return "Try Again"
        else:
            kWload = systems['secondary_kWload']
            kVAload = kWload/pf
    
    currentlow = ((kVAload)/phases)/(lvll)
    
    return "This is weird"
        
    
def thingstoremember():
    print(' - Distribution System Transformers ae rated on Line to Line Voltage. So, voltage across a phase to neutral must be calculated by converting to line to neutral. \n')
    print('- Transformer with grounded neutral carry 2/3 of total current or KVA. The two carry 1/3 each.[Ask Dr.Liu]')
    

def lltoln(value):
    value = value/np.sqrt(3)
    return value

def lntoll(value):
    value = value*np.sqrt(3)
    return value

def threephaseloadcomponents(threephaseload,pf,lag,voltagell):
    theta = np.arccos(pf)
    if lag == 'lag':
         theta = -theta
    else:
        theta = theta
        
    print('Using Voltage Drop Van as the reference:\n')        
    Ia3ph = threephaseload/(np.sqrt(3)*voltagell)
    Ib3ph = Ia3ph  #threephaseload/(np.sqrt(3)*voltagell)
    Ic3ph = Ia3ph #threephaseload/(np.sqrt(3)*voltagell)
    Ia3ph = Ia3ph*((np.cos(theta))+1j*(np.sin(theta)))
    Ib3ph = (-0.5-1j*0.866)*Ia3ph
    Ic3ph = (-0.5+1j*0.866)*Ia3ph
    print('--> Ia3ph = %f /_ %f \n--> Ib3ph = %f /_ %f \n--> Ic3ph = %f /_ %f' %(np.abs(Ia3ph),np.angle(Ia3ph,deg=True),np.abs(Ib3ph),np.angle(Ib3ph,deg=True),np.abs(Ic3ph),np.angle(Ic3ph,deg=True)))  
    return Ia3ph, Ib3ph, Ic3ph

def singlephaseloadcomponents(singlephaseload,pf,lag, voltagell):
    theta = np.arccos(pf)
    if lag == 'lag':
         theta = -theta
    else:
        theta = theta
    print('Using Voltage Drop Van as the reference:\n')
    Iph =  singlephaseload/voltagell
    Iphangle = -90 + np.rad2deg(theta)
    print('---> I1ph = %f /_ %f ' %(Iph, Iphangle))
    
    return Iph, Iphangle

def secondarywindingcurrents():
    return "hello"

def primarywindingcurrents():
    return "world"



def opendeltaopendelta(threephasepower, pf, lag, voltagell):
    theta = np.arccos(pf) #theta is the load power factor
    if lag == 'lag':
         theta = -theta
    else:
        theta = theta   
    theta = np.rad2deg(theta)
    print('Using Voltage Drop Van as the reference, i.e. /_ V_an = 0 degrees:\n')
    theta_ia = 0 - theta  
    theta_ib = -120 - theta  
    theta_ic = 120 - theta  
    
    IaMag = threephasepower/(np.sqrt(3)*voltagell)
    IaAng = theta_ia
    IbMag = threephasepower/(np.sqrt(3)*voltagell)
    IbAng = theta_ib
    IcMag = threephasepower/(np.sqrt(3)*voltagell)
    IcAng = theta_ic
    
    ST_each = (threephasepower/np.sqrt(3))
    transformerbankmaxload = 2*ST_each
    
    totalpoweroutputofthebank = voltagell*((IaMag*np.cos(theta+30))+(IcMag*np.cos(theta-30)))
    totalreactivepoweroutputofthebank = voltagell*((IaMag*np.sin(theta+30))+(IcMag*np.sin(theta-30)))
    
    print('--> Ia = %f /_ %f \n--> Ib = %f /_ %f \n--> Ic = %f /_ %f \n' %(IaMag, IaAng, IbMag, IbAng, IcMag, IcAng))
    print('--> Maximum loading of the transformer bank possible = %f kVA' %transformerbankmaxload)
    print('--> Total Power Output of the Delta-Delta Bank = %f kW' %totalpoweroutputofthebank)
    print('--> Total Reactive Power Output of the Delta-Delta Bank = %f kVAr' %totalreactivepoweroutputofthebank)

def starstar():
    print('\n In Y-Y transformer bank connection, only 57.7% of line voltage affects each winding, but full line current flows in each transformer winding. \n')

def stardelta():
    print('\n In Y-D transformer bank connection, voltage between outside the legs of Y connection is 1.732 times the voltage of the neutral. \n')

